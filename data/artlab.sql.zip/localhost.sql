-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Mar 23, 2010 at 09:03 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `artlab`
-- 
CREATE DATABASE `artlab` DEFAULT CHARACTER SET latin1 COLLATE latin1_general_ci;
USE `artlab`;

-- --------------------------------------------------------

-- 
-- Table structure for table `lab_admins`
-- 

CREATE TABLE `lab_admins` (
  `admin_id` int(11) NOT NULL auto_increment,
  `admin_username` varchar(30) character set latin1 collate latin1_general_ci NOT NULL,
  `admin_password` varchar(30) character set latin1 collate latin1_general_ci NOT NULL,
  `admin_level` int(11) NOT NULL default '0',
  PRIMARY KEY  (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `lab_admins`
-- 

INSERT INTO `lab_admins` (`admin_id`, `admin_username`, `admin_password`, `admin_level`) VALUES 
(1, 'admin', 'admin', -1);

-- --------------------------------------------------------

-- 
-- Table structure for table `lab_blocks`
-- 

CREATE TABLE `lab_blocks` (
  `block_id` int(11) NOT NULL auto_increment,
  `page_id` int(11) default '0',
  `block_title` varchar(50) character set latin1 collate latin1_general_ci default NULL,
  `block_has_title` enum('Y','N') character set latin1 collate latin1_general_ci default 'N',
  `block_direction` enum('LEFT','RIGHT') character set latin1 collate latin1_general_ci default 'LEFT',
  `block_content` text character set latin1 collate latin1_general_ci,
  `block_order` int(11) default '0',
  PRIMARY KEY  (`block_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=23 ;

-- 
-- Dumping data for table `lab_blocks`
-- 

INSERT INTO `lab_blocks` (`block_id`, `page_id`, `block_title`, `block_has_title`, `block_direction`, `block_content`, `block_order`) VALUES 
(1, 0, 'Test Left Block', 'N', 'LEFT', '<p>!mainmenu</p>', 1),
(2, 8, NULL, 'N', 'LEFT', NULL, 1),
(17, 9, NULL, 'N', 'LEFT', NULL, 0),
(18, 9, NULL, 'N', 'RIGHT', NULL, 0),
(20, 4, NULL, 'N', 'RIGHT', NULL, 0),
(22, 10, NULL, 'N', 'RIGHT', NULL, 0),
(3, 1, 'Our Services', 'N', 'LEFT', '!services', 0),
(4, 2, 'Portfolio Categories', 'N', 'LEFT', '!portfolio', 0),
(5, 0, 'News', 'Y', 'RIGHT', '<p>!featurednews</p>', 0),
(6, 0, 'Clients', 'Y', 'RIGHT', '<p>!featuredclients</p>', 2),
(8, 7, NULL, 'N', 'LEFT', NULL, 0),
(9, 6, NULL, 'N', 'LEFT', NULL, 0),
(10, 5, NULL, 'N', 'LEFT', NULL, 0),
(15, 4, NULL, 'N', 'LEFT', NULL, 0),
(16, 6, NULL, 'N', 'RIGHT', NULL, 0),
(12, 5, NULL, 'N', 'RIGHT', NULL, 0),
(13, 7, NULL, 'N', 'RIGHT', NULL, 0),
(21, 10, NULL, 'N', 'LEFT', NULL, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `lab_categories`
-- 

CREATE TABLE `lab_categories` (
  `category_id` int(11) NOT NULL auto_increment,
  `category_title` varchar(50) character set latin1 collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`category_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `lab_categories`
-- 

INSERT INTO `lab_categories` (`category_id`, `category_title`) VALUES 
(1, 'Corporate Identity'),
(2, 'Ads and Posters'),
(3, 'Brochures and Drop Cards'),
(4, 'Flyers'),
(5, 'Packs and OTC'),
(6, 'Rollups and Popups');

-- --------------------------------------------------------

-- 
-- Table structure for table `lab_clients`
-- 

CREATE TABLE `lab_clients` (
  `client_id` int(11) NOT NULL auto_increment,
  `client_title` varchar(50) character set latin1 collate latin1_general_ci default NULL,
  `client_brief` varchar(255) character set latin1 collate latin1_general_ci default NULL,
  `client_thumbnail` varchar(255) character set latin1 collate latin1_general_ci default NULL,
  `client_image` varchar(255) character set latin1 collate latin1_general_ci default NULL,
  `client_featured` enum('Y','N') character set latin1 collate latin1_general_ci NOT NULL default 'N',
  `client_order` int(11) default '0',
  `client_date_submited` date default '0000-00-00',
  `client_date_updated` date default '0000-00-00',
  PRIMARY KEY  (`client_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21 ;

-- 
-- Dumping data for table `lab_clients`
-- 

INSERT INTO `lab_clients` (`client_id`, `client_title`, `client_brief`, `client_thumbnail`, `client_image`, `client_featured`, `client_order`, `client_date_submited`, `client_date_updated`) VALUES 
(1, 'test first client photos', 'test first client photos cool test first client photos cool', 'logo_engiro_life.gif', NULL, 'Y', 1, '2009-07-28', '2009-08-01'),
(2, 'test first client photos', 'test first client photos cool test first client photos cool', 'logo_eum.gif', '2503_03.jpg', 'Y', 2, '2009-07-28', '2009-08-01'),
(3, 'test first client photos', 'test first client photos cool test first client photos cool', 'logo_hayat.gif', '2503_03.jpg', 'Y', 3, '2009-07-28', '2009-08-01'),
(4, 'test first client photos', 'test first client photos cool test first client photos cool', 'logo_api.gif', '2503_03.jpg', 'Y', 4, '2009-07-28', '2009-08-01'),
(5, 'test first client photos', 'test first client photos cool test first client photos cool', 'logo_alraed.gif', '2503_03.jpg', 'N', 5, '2009-07-28', '2009-08-01'),
(6, NULL, NULL, 'logo_orient_montreal.gif', NULL, 'N', 6, '2009-08-01', '0000-00-00'),
(7, NULL, NULL, 'logo_kfunc.gif', NULL, 'N', 7, '2009-08-01', '0000-00-00'),
(8, NULL, NULL, 'logo_trust_quality.gif', NULL, 'N', 8, '2009-08-01', '0000-00-00'),
(9, NULL, NULL, 'logo_ems.gif', NULL, 'N', 9, '2009-08-01', '0000-00-00'),
(10, NULL, NULL, 'logo_rmedical.gif', NULL, 'N', 10, '2009-08-01', '0000-00-00'),
(11, NULL, NULL, 'logo_punited.gif', NULL, 'N', 11, '2009-08-01', '0000-00-00'),
(12, NULL, NULL, 'logo_pharma_int.gif', NULL, 'N', 12, '2009-08-01', '0000-00-00'),
(13, NULL, NULL, 'logo_aragen.gif', NULL, 'N', 13, '2009-08-01', '0000-00-00'),
(14, NULL, NULL, 'logo_jo_river.gif', NULL, 'N', 14, '2009-08-01', '0000-00-00'),
(15, NULL, NULL, 'logo_mid_pharma.gif', NULL, 'N', 15, '2009-08-01', '0000-00-00'),
(16, NULL, NULL, 'logo_sevant.gif', NULL, 'N', 16, '2009-08-01', '0000-00-00'),
(17, NULL, NULL, 'logo_delass.gif', NULL, 'N', 17, '2009-08-01', '0000-00-00'),
(18, NULL, NULL, 'logo_dar_aldawa.gif', NULL, 'N', 18, '2009-08-01', '0000-00-00'),
(19, NULL, NULL, 'logo_hekma.gif', NULL, 'N', 19, '2009-08-01', '0000-00-00'),
(20, NULL, NULL, 'logo_msd.gif', NULL, 'N', 20, '2009-08-01', '0000-00-00');

-- --------------------------------------------------------

-- 
-- Table structure for table `lab_contacts`
-- 

CREATE TABLE `lab_contacts` (
  `contact_id` int(11) NOT NULL auto_increment,
  `contact_name` varchar(50) character set latin1 collate latin1_general_ci default NULL,
  `contact_email` varchar(50) character set latin1 collate latin1_general_ci default NULL,
  `contact_type` varchar(50) character set latin1 collate latin1_general_ci default NULL,
  `contact_company` varchar(50) collate utf8_unicode_ci default NULL,
  `contact_title` varchar(50) collate utf8_unicode_ci default NULL,
  `contact_subject` varchar(50) character set latin1 collate latin1_general_ci default NULL,
  `contact_message` text character set latin1 collate latin1_general_ci,
  `contact_date_submited` date default '0000-00-00',
  PRIMARY KEY  (`contact_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

-- 
-- Dumping data for table `lab_contacts`
-- 

INSERT INTO `lab_contacts` (`contact_id`, `contact_name`, `contact_email`, `contact_type`, `contact_company`, `contact_title`, `contact_subject`, `contact_message`, `contact_date_submited`) VALUES 
(1, 'Abood Radwan', 'abood_radwan@yahoo.com', 'Feedback', NULL, NULL, 'Testing issue', 'I would like to know if the anything that support my problem', '0000-00-00'),
(2, 'Abood Radwan', 'abood_radwan@yahoo.com', 'Feedback', NULL, NULL, 'Testing issue', 'I would like to know if the anything that support my problem', '0000-00-00'),
(3, 'Abood Radwan', 'abood_radwan@yahoo.com', 'Feedback', NULL, NULL, 'Testing issue', 'I would like to know if the anything that support my problem', '0000-00-00'),
(4, 'Abood Radwan', 'abood_radwan@yahoo.com', 'Feedback', NULL, NULL, 'Testing issue', 'I would like to know if the anything that support my problem', '0000-00-00'),
(5, 'Abood Radwan', 'abood_radwan@yahoo.com', 'Feedback', NULL, NULL, 'Testing issue', 'I would like to know if the anything that support my problem', '2009-07-27'),
(6, 'abood radwan', 'abood_radwan@yahoo.com', 'feedback', NULL, NULL, 'hello world', 'I like this game Mario ', '2009-07-27'),
(7, 'abood radwan', 'abood_radwan@hotmail.com', 'feedback', NULL, NULL, 'just testing the system', 'making for unit test on this website.<br />\r\n<br />\r\nwishes, <br />\r\n<br />\r\nand I hope it works very good ', '2009-08-01'),
(8, 'nidal', 'nidal@aktco.com', 'feedback', NULL, NULL, 'test', 'test', '2009-08-03'),
(9, 'sfasdf', 'smd@yahoo.com', 'feedback', NULL, NULL, 'fdadsf', 'asdfas', '2009-08-03'),
(10, 's', 'sss@yahoo.com', 'feedback', NULL, NULL, 'fasdf', 'adsfad', '2009-08-03'),
(11, '7ytg7t', 'yt6f@yahoo.com', 'uyyt', NULL, NULL, 'tft', 'rftf', '2009-08-04'),
(12, 'ddfasdf', 'dkdk@yahoo.com', '', NULL, NULL, 'dkdkdj', 'kfkkjadf', '2009-08-04'),
(13, 'gdsfg', 'sdfg@yahoo.com', 'sdfggf', NULL, NULL, 'fgsdf', 'sdfgsdfg', '2009-08-04'),
(14, 'yazan', 'yazan_raie@yahoo.com', '', NULL, NULL, 'your services', 'hi', '2009-08-05'),
(15, 'rami', 'info@artlabjo.com', '', NULL, NULL, 'Test', 'Test', '2009-08-06'),
(16, 'abood radwan', 'abood_radwan@yahoo.com', '', 'Visiosight', 'Team Leader', 'Wow things', 'I love this game Mario', '2009-08-08'),
(17, 'rami', 'info@artlabjo.com', '', '', '', 'hi', 'hi', '2009-08-18'),
(18, 'df', 'dkdk@yahoo.com', '', 'sfa', 'fs', 'sdf', 'sadf', '2009-08-22');

-- --------------------------------------------------------

-- 
-- Table structure for table `lab_controls`
-- 

CREATE TABLE `lab_controls` (
  `control_id` int(11) NOT NULL auto_increment,
  `control_name` varchar(50) character set latin1 collate latin1_general_ci default NULL,
  `control_file` varchar(255) character set latin1 collate latin1_general_ci NOT NULL,
  `control_description` varchar(255) character set latin1 collate latin1_general_ci default NULL,
  PRIMARY KEY  (`control_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `lab_controls`
-- 

INSERT INTO `lab_controls` (`control_id`, `control_name`, `control_file`, `control_description`) VALUES 
(1, 'news.module', 'news.module.php', 'this is for artlab news, which includes lists and details as well.'),
(2, 'contact.module', 'contact.module.php', 'this module allow users to contact directly with the web admin by adding user information into the database and sends email to the admin'),
(3, 'services.module', 'services.module.php', 'listing all service added to the system, and output the service in a will format'),
(4, 'clients.module', 'clients.module.php', 'this module provides clients page with nice interaction'),
(5, 'portfolios.module', 'portfolios.module.php', 'company portfolio');

-- --------------------------------------------------------

-- 
-- Table structure for table `lab_news`
-- 

CREATE TABLE `lab_news` (
  `news_id` int(11) NOT NULL auto_increment,
  `news_title` varchar(50) character set latin1 collate latin1_general_ci default NULL,
  `news_brief` varchar(255) character set latin1 collate latin1_general_ci default NULL,
  `news_description` text character set latin1 collate latin1_general_ci,
  `news_thumbnail` varchar(255) character set latin1 collate latin1_general_ci default NULL,
  `news_featured` enum('Y','N') collate utf8_unicode_ci default 'N',
  `news_order` int(11) default NULL,
  `news_date_submited` date default '0000-00-00',
  `news_date_updated` date default '0000-00-00',
  PRIMARY KEY  (`news_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `lab_news`
-- 

INSERT INTO `lab_news` (`news_id`, `news_title`, `news_brief`, `news_description`, `news_thumbnail`, `news_featured`, `news_order`, `news_date_submited`, `news_date_updated`) VALUES 
(1, 'artlab news', 'Artlab is expanding its scope of services...read more', '<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<h3>Artlab is expanding its scope of services.</h3>\r\n<p>Additional services have been added to&nbsp;Artlab former services of&nbsp;Graphic Design, Artwork &amp;&nbsp;Printing, to professionally match the continuously developing requirements of pharmaceutical &amp; medical companies. New services include: website design, photography, pharmaceutical &amp; medical copywriting, translation and promotional items.&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>', 'news_img.jpg', 'Y', 1, '2009-07-27', '2009-08-13');

-- --------------------------------------------------------

-- 
-- Table structure for table `lab_pages`
-- 

CREATE TABLE `lab_pages` (
  `page_id` int(11) NOT NULL default '0',
  `control_id` int(11) default '0',
  `page_name` varchar(30) collate utf8_unicode_ci NOT NULL,
  `page_title` varchar(255) character set latin1 collate latin1_general_ci default NULL,
  `page_description` text character set latin1 collate latin1_general_ci,
  `page_meta_keyword` varchar(255) character set latin1 collate latin1_general_ci NOT NULL,
  `page_meta_description` varchar(255) character set latin1 collate latin1_general_ci NOT NULL,
  `page_order` int(11) default NULL,
  `page_status` enum('Y','N') collate utf8_unicode_ci default 'N',
  `page_date_submited` date NOT NULL default '0000-00-00',
  `page_date_updated` date NOT NULL default '0000-00-00',
  PRIMARY KEY  (`page_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `lab_pages`
-- 

INSERT INTO `lab_pages` (`page_id`, `control_id`, `page_name`, `page_title`, `page_description`, `page_meta_keyword`, `page_meta_description`, `page_order`, `page_status`, `page_date_submited`, `page_date_updated`) VALUES 
(0, NULL, 'Home', 'Home | Art Lab', '<div style="margin: 0px 25px 0px 15px;">\r\n<p style="text-align: justify;"><span style="display: none;" id="1249366298637S">&nbsp;</span><span style="display: none;" id="1249366294862S">&nbsp;</span></p>\r\n<p style="text-align: justify;"><span style="display: none;" id="1249366249156S">&nbsp;</span><span style="display: none;" id="1249366243837S">&nbsp;</span></p>\r\n<p style="text-align: justify;">Artlab is a unique Graphic Design &amp; Printing Services Studio with a major objective of professionally serving pharmaceutical &amp; medical companies and helping them achieve their marketing goals by providing high quality services for their promotional tools.</p>\r\n<p style="text-align: justify;">&nbsp;</p>\r\n<p style="text-align: justify;">Since its establishment in 2006, Artlab has seen many of its clients'' businesses grow; this along with a continuously increasing number of clients over the past years has contributed to the good image and reputation Artlab owns today.</p>\r\n<p style="text-align: justify;">&nbsp;</p>\r\n<p style="text-align: justify;">With a professional staff of Graphic Designers, Artists &amp; Pharmacists who have excellent knowledge in the pharmaceutical &amp; medical fields, a strong background in pharmaceutical promotion &amp; creative graphic design and artwork skills, Artlab continues to professionally serve its clients by providing high quality graphic design and printing services that perfectly match their needs.</p>\r\n<p style="text-align: justify;">&nbsp;</p>\r\n<p style="text-align: justify;">We like to think of ourselves as your professional graphic design partner. We can help you create &amp; improve your corporate image and enhance your business profile &amp; performance.</p>\r\n</div>\r\n<p style="text-align: justify;">&nbsp;</p>', 'Art Lab jo, ArtLab jo, ArtLabJo, ArtLabJo.com, ARTLAB Jordan Amman, Graphic Design, Pharmaceutical Graphic Design, Pharmaceutical, Pharmacists in Jordan, Graphic Design in Jordan, Pharmacy, Pharmacy in Jordan, Medical Packaging, Product Specialist, Medica', 'Graphic Design Agency Specialized in Pharmaceutical Graphic Design and Identity Design, Brochures, Posters, Ads, Advertising, Drop Cards, Flyers, Packs, OCT, Rollups, Popups, Drawing and Clipart, Printing, Copywriting & Translation, Photography, Promotion', 0, 'Y', '2009-07-25', '2009-08-22'),
(1, 3, 'Our Services', 'Our Services | Art Lab', '<h1>Our Services</h1>\r\n<p>&nbsp;</p>', 'Art Lab jo, ArtLab jo, ArtLabJo, ArtLabJo.com, ARTLAB Jordan Amman, Graphic Design, Pharmaceutical Graphic Design, Pharmaceutical, Pharmacists in Jordan, Graphic Design in Jordan, Pharmacy, Pharmacy in Jordan, Medical Packaging, Product Specialist, Medica', 'Graphic Design Agency Specialized in Pharmaceutical Graphic Design and Identity Design, Brochures, Posters, Ads, Advertising, Drop Cards, Flyers, Packs, OCT, Rollups, Popups, Drawing and Clipart, Printing, Copywriting & Translation, Photography, Promotion', 2, 'Y', '2009-07-25', '2009-08-13'),
(2, 5, 'Portfolio', 'Portfolio | Art Lab', NULL, 'Art Lab jo, ArtLab jo, ArtLabJo, ArtLabJo.com, ARTLAB Jordan Amman, Graphic Design, Pharmaceutical Graphic Design, Pharmaceutical, Pharmacists in Jordan, Graphic Design in Jordan, Pharmacy, Pharmacy in Jordan, Medical Packaging, Product Specialist, Medica', 'Graphic Design Agency Specialized in Pharmaceutical Graphic Design and Identity Design, Brochures, Posters, Ads, Advertising, Drop Cards, Flyers, Packs, OCT, Rollups, Popups, Drawing and Clipart, Printing, Copywriting & Translation, Photography, Promotion', 3, 'Y', '2009-07-25', '2009-08-13'),
(3, 4, 'Clients', 'Clients | Art Lab', '<h1>Clients</h1>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>', 'Art Lab jo, ArtLab jo, ArtLabJo, ArtLabJo.com, ARTLAB Jordan Amman, Graphic Design, Pharmaceutical Graphic Design, Pharmaceutical, Pharmacists in Jordan, Graphic Design in Jordan, Pharmacy, Pharmacy in Jordan, Medical Packaging, Product Specialist, Medica', 'Graphic Design Agency Specialized in Pharmaceutical Graphic Design and Identity Design, Brochures, Posters, Ads, Advertising, Drop Cards, Flyers, Packs, OCT, Rollups, Popups, Drawing and Clipart, Printing, Copywriting & Translation, Photography, Promotion', 4, 'Y', '2009-07-25', '2009-08-13'),
(10, NULL, 'Useful Links', 'Useful Links', '<h2>Useful Links</h2>\r\n<p>&nbsp;</p>\r\n<h4>Jordan Pharmacist Association</h4>\r\n<p><a href="http://www.jpa.org.jo">www.jpa.org.jo</a></p>\r\n<p>&nbsp;</p>\r\n<h4>Pharma Jo</h4>\r\n<p><a href="http://www.pharmajo.com">www.pharmajo.com</a></p>\r\n<p>&nbsp;</p>\r\n<h4>JFDA</h4>\r\n<p><a href="http://www.jfda.jo/en/default/">www.jfda.jo</a></p>\r\n<p>&nbsp;</p>\r\n<h4>The Arabic Medical Dictionary</h4>\r\n<p><a href="http://www.altibbi.com">www.altibbi.com</a></p>\r\n<p>&nbsp;</p>\r\n<h4>BMJ</h4>\r\n<p><a href="http://www.bmj.com">www.bmj.com</a></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>', 'Art Lab jo, ArtLab jo, ArtLabJo, ArtLabJo.com, ARTLAB Jordan Amman, Graphic Design, Pharmaceutical Graphic Design, Pharmaceutical, Pharmacists in Jordan, Graphic Design in Jordan, Pharmacy, Pharmacy in Jordan, Medical Packaging, Product Specialist, Medica', 'Graphic Design Agency Specialized in Pharmaceutical Graphic Design and Identity Design, Brochures, Posters, Ads, Advertising, Drop Cards, Flyers, Packs, OCT, Rollups, Popups, Drawing and Clipart, Printing, Copywriting & Translation, Photography, Promotion', 15, 'Y', '2009-08-08', '2009-08-13'),
(4, 2, 'Contact Us', 'Contact Us | Art Lab', '<h1>Contact Us</h1>\r\n<p>&nbsp;</p>\r\n<table width="100%" cellspacing="1" cellpadding="1" border="0">\r\n    <tbody>\r\n       \r\n        <tr>\r\n            <td>\r\n            <h4><span style="color: rgb(245, 160, 26);">P.O. Box:</span></h4>\r\n            <p>1197 Amman<br />\r\n            11941 Jordan</p>\r\n            </td>\r\n            <td>\r\n            <h4><span style="color: rgb(245, 160, 26);">E-mail</span></h4>\r\n            <p>info@artlabjo.com</p>\r\n            </td>\r\n        </tr>\r\n        <tr>\r\n            <td>\r\n            <h4><span style="color: rgb(245, 160, 26);">Phone/Fax</span></h4>\r\n            <p>+962 (6) 5343108<br />\r\n            +962 (6) 5355170</p>\r\n            </td>\r\n            <td>\r\n            <h4><span style="color: rgb(245, 160, 26);">Office Location </span></h4>\r\n            <p>Jordan, amman<br />\r\n            Ahmad Al Tarawina Street<br />\r\n            University of jordan commercial complex, 3rd floor</p>\r\n            </td>\r\n        </tr>\r\n <tr>\r\n            <td colspan="2">\r\n            <h4><span style="color: rgb(245, 160, 26);">Contact Person<br />\r\n            </span></h4>\r\n            <p>Name: Rami J. Khalifeh<br />\r\n            Title: Art Director / Pharmacist</p>\r\n            </td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<h4><span style="color: rgb(245, 160, 26);">Write a Message</span></h4>\r\n<p>&nbsp;</p>', 'Art Lab jo, ArtLab jo, ArtLabJo, ArtLabJo.com, ARTLAB Jordan Amman, Graphic Design, Pharmaceutical Graphic Design, Pharmaceutical, Pharmacists in Jordan, Graphic Design in Jordan, Pharmacy, Pharmacy in Jordan, Medical Packaging, Product Specialist, Medica', 'Graphic Design Agency Specialized in Pharmaceutical Graphic Design and Identity Design, Brochures, Posters, Ads, Advertising, Drop Cards, Flyers, Packs, OCT, Rollups, Popups, Drawing and Clipart, Printing, Copywriting & Translation, Photography, Promotion', 20, 'Y', '2009-07-25', '2009-08-22'),
(5, NULL, 'About', 'About | Art Lab', '<h1>About</h1>\r\n<p>&nbsp;</p>\r\n<p>Artlab is a unique Graphic Design &amp; Printing Services Studio with a major objective of professionally serving pharmaceutical &amp; medical companies and helping them achieve their marketing goals by providing high quality services for their promotional tools.</p>\r\n<p>Since its establishment in 2006, Artlab has seen many of its clients'' businesses grow; this along with a continuously increasing number of clients over the past years has contributed to the good image and reputation Artlab owns today.</p>\r\n<p>With a professional staff of Graphic Designers, Artists &amp; Pharmacists who have excellent knowledge in the pharmaceutical &amp; medical fields, a strong background in pharmaceutical promotion &amp; creative graphic design and artwork skills, Artlab continues to professionally serve its clients by providing high quality graphic design and printing services that perfectly match their needs.</p>\r\n<p>We like to think of ourselves as your professional graphic design partner. We can help you create &amp; improve your corporate image and enhance your business profile &amp; performance.</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>', 'Art Lab jo, ArtLab jo, ArtLabJo, ArtLabJo.com, ARTLAB Jordan Amman, Graphic Design, Pharmaceutical Graphic Design, Pharmaceutical, Pharmacists in Jordan, Graphic Design in Jordan, Pharmacy, Pharmacy in Jordan, Medical Packaging, Product Specialist, Medica', 'Graphic Design Agency Specialized in Pharmaceutical Graphic Design and Identity Design, Brochures, Posters, Ads, Advertising, Drop Cards, Flyers, Packs, OCT, Rollups, Popups, Drawing and Clipart, Printing, Copywriting & Translation, Photography, Promotion', 6, 'N', '2009-07-25', '2009-08-13'),
(6, NULL, 'Privacy Policy', 'Privacy Policy | Art Lab', '<h1>&nbsp;</h1>\r\n<h1>&nbsp;</h1>\r\n<p>&nbsp;</p>\r\n<h1>&nbsp;</h1>\r\n<h1>Privacy Policy</h1>\r\n<p>&nbsp;</p>\r\n<p>We gladly sign and abide by confidentiality agreements to guarantee that our client''s information is accessible only to those authorized to have access.</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>', 'Art Lab jo, ArtLab jo, ArtLabJo, ArtLabJo.com, ARTLAB Jordan Amman, Graphic Design, Pharmaceutical Graphic Design, Pharmaceutical, Pharmacists in Jordan, Graphic Design in Jordan, Pharmacy, Pharmacy in Jordan, Medical Packaging, Product Specialist, Medica', 'Graphic Design Agency Specialized in Pharmaceutical Graphic Design and Identity Design, Brochures, Posters, Ads, Advertising, Drop Cards, Flyers, Packs, OCT, Rollups, Popups, Drawing and Clipart, Printing, Copywriting & Translation, Photography, Promotion', 7, 'Y', '2009-07-25', '2009-08-13'),
(7, NULL, 'Careers', 'Careers | Art Lab', '<h1>Careers</h1>\r\n<p>&nbsp;</p>\r\n<p>ARTLAB is seeking to recruit Graphic Designers with excellent command of Adobe Indesign,&nbsp;preferably with good&nbsp;experience in Books or Magazines design.</p>\r\n<p>We welcome Talented Graphic Designers, Illustrators, Animators, Web Designers &amp; Sales People.</p>\r\n<p>Please send your resume to <span style="color: rgb(245, 160, 26);"><a href="mailto:info@artlabjo.com">info@artlabjo.com</a></span></p>\r\n<h3>&nbsp;</h3>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>', 'Art Lab jo, ArtLab jo, ArtLabJo, ArtLabJo.com, ARTLAB Jordan Amman, Graphic Design, Pharmaceutical Graphic Design, Pharmaceutical, Pharmacists in Jordan, Graphic Design in Jordan, Pharmacy, Pharmacy in Jordan, Medical Packaging, Product Specialist, Medica', 'Graphic Design Agency Specialized in Pharmaceutical Graphic Design and Identity Design, Brochures, Posters, Ads, Advertising, Drop Cards, Flyers, Packs, OCT, Rollups, Popups, Drawing and Clipart, Printing, Copywriting & Translation, Photography, Promotion', 9, 'Y', '2009-07-25', '2009-08-13'),
(8, 1, 'News', 'News | Art Lab', '<h1>News</h1>\r\n<p>&nbsp;</p>', 'Art Lab jo, ArtLab jo, ArtLabJo, ArtLabJo.com, ARTLAB Jordan Amman, Graphic Design, Pharmaceutical Graphic Design, Pharmaceutical, Pharmacists in Jordan, Graphic Design in Jordan, Pharmacy, Pharmacy in Jordan, Medical Packaging, Product Specialist, Medica', 'Graphic Design Agency Specialized in Pharmaceutical Graphic Design and Identity Design, Brochures, Posters, Ads, Advertising, Drop Cards, Flyers, Packs, OCT, Rollups, Popups, Drawing and Clipart, Printing, Copywriting & Translation, Photography, Promotion', 10, 'Y', '2009-07-26', '2009-08-13'),
(9, NULL, 'Thank You', 'Thank You', '<h4 style="text-align: center;">Your message has been successfully sent.</h4>\r\n<h4 style="text-align: center;">&nbsp;</h4>\r\n<h4 style="text-align: center;">Thank You</h4>\r\n<h4 style="text-align: center;">&nbsp;</h4>\r\n<h4 style="text-align: center;">We will get back to you shortly.</h4>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>', 'Art Lab jo, ArtLab jo, ArtLabJo, ArtLabJo.com, ARTLAB Jordan Amman, Graphic Design, Pharmaceutical Graphic Design, Pharmaceutical, Pharmacists in Jordan, Graphic Design in Jordan, Pharmacy, Pharmacy in Jordan, Medical Packaging, Product Specialist, Medica', 'Graphic Design Agency Specialized in Pharmaceutical Graphic Design and Identity Design, Brochures, Posters, Ads, Advertising, Drop Cards, Flyers, Packs, OCT, Rollups, Popups, Drawing and Clipart, Printing, Copywriting & Translation, Photography, Promotion', 11, 'N', '2009-07-27', '2009-08-22');

-- --------------------------------------------------------

-- 
-- Table structure for table `lab_portfolios`
-- 

CREATE TABLE `lab_portfolios` (
  `portfolio_id` int(11) NOT NULL auto_increment,
  `category_id` int(11) NOT NULL default '0',
  `portfolio_title` varchar(50) collate latin1_general_ci default NULL,
  `portfolio_brief` varchar(255) collate latin1_general_ci default NULL,
  `portfolio_thumbnail` varchar(255) collate latin1_general_ci default NULL,
  `portfolio_image` varchar(255) collate latin1_general_ci default NULL,
  `portfolio_order` int(11) default '0',
  `portfolio_date_submited` date default '0000-00-00',
  `portfolio_date_update` date default '0000-00-00',
  `portfolio_temp` varchar(59) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`portfolio_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=58 ;

-- 
-- Dumping data for table `lab_portfolios`
-- 

INSERT INTO `lab_portfolios` (`portfolio_id`, `category_id`, `portfolio_title`, `portfolio_brief`, `portfolio_thumbnail`, `portfolio_image`, `portfolio_order`, `portfolio_date_submited`, `portfolio_date_update`, `portfolio_temp`) VALUES 
(12, 3, 'Azicure', NULL, 'azicure_small.jpg', 'azicure.jpg', 0, '2009-08-02', '0000-00-00', NULL),
(13, 4, 'Energex', NULL, 'energex_small.jpg', 'energex.jpg', 0, '2009-08-02', '0000-00-00', NULL),
(14, 4, 'Gastrifam', NULL, 'gastrifam_small.jpg', 'gastrifam.jpg', 0, '2009-08-02', '0000-00-00', NULL),
(11, 3, 'Glucoflex', NULL, 'glucoflex_small.jpg', 'glucoflex.jpg', 0, '2009-08-02', '0000-00-00', NULL),
(18, 1, 'TQ Pharma', NULL, 'tq_small.jpg', 'tq.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(10, 2, 'Echimmune', NULL, 'ech_small.jpg', 'ech.jpg', 1, '2009-08-02', '2009-08-05', NULL),
(19, 1, 'Tamara', NULL, 'tamara_small.jpg', 'tamara.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(20, 1, 'Nadara', NULL, 'nadara_small.jpg', 'nadara.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(9, 2, 'Jo River', NULL, 'joriver_small.jpg', 'joriver.jpg', 0, '2009-08-02', '2009-08-05', NULL),
(21, 1, 'Kids Fun', NULL, 'kidsfun_small.jpg', 'kidsfun.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(7, 1, 'seven dimensions', NULL, '7d_small.jpg', '7d.jpg', 0, '2009-08-02', '0000-00-00', NULL),
(8, 1, 'Amgen', NULL, 'amgen_small.jpg', 'amgen.jpg', 0, '2009-08-02', '0000-00-00', NULL),
(15, 5, 'Helix', NULL, 'helix_small.jpg', 'helix.jpg', 0, '2009-08-02', '0000-00-00', NULL),
(16, 5, 'Nasal Spray', NULL, 'nasal-spray_small.jpg', 'nasal-spray.jpg', 0, '2009-08-02', '0000-00-00', NULL),
(17, 6, 'Hypodipine', NULL, 'hypodipine_small.jpg', 'hypodipine.jpg', 0, '2009-08-02', '0000-00-00', NULL),
(22, 2, NULL, NULL, 'posters_small.jpg', 'posters.jpg', 4, '2009-08-05', '2009-08-05', NULL),
(23, 2, NULL, NULL, 'gincata_small.jpg', 'gincata.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(24, 2, 'Aktco', NULL, 'aktco_small.jpg', 'aktco.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(25, 3, NULL, NULL, 'vademecum_small.jpg', 'vademecum.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(26, 3, NULL, NULL, 'suraxim_small.jpg', 'suraxim.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(27, 3, NULL, NULL, 'rixopharm_small.jpg', 'rixopharm.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(28, 3, NULL, NULL, 'rispons_small.jpg', 'rispons.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(29, 3, NULL, NULL, 'risdon_small.jpg', 'risdon.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(30, 3, NULL, NULL, 'pantover_small.jpg', 'pantover.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(31, 3, NULL, NULL, 'omega3_small.jpg', 'omega3.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(32, 3, NULL, NULL, 'myofreez_small.jpg', 'myofreez.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(33, 3, NULL, NULL, 'midofen_small.jpg', 'midofen.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(34, 3, NULL, NULL, 'maxim_small.jpg', 'maxim.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(35, 3, NULL, NULL, 'lansomid_small.jpg', 'lansomid.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(36, 3, NULL, NULL, 'joflam_small.jpg', 'joflam.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(37, 3, NULL, NULL, 'hpv_small.jpg', 'hpv.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(38, 3, NULL, NULL, 'fosavance_small.jpg', 'fosavance.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(39, 3, NULL, NULL, 'exofen_small.jpg', 'exofen.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(40, 3, NULL, NULL, 'echimmune_small.jpg', 'echimmune.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(41, 3, NULL, NULL, 'descover_small.jpg', 'descover.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(42, 3, NULL, NULL, 'clotrex_small.jpg', 'clotrex.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(43, 3, NULL, NULL, 'ciprover_small.jpg', 'ciprover.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(44, 3, NULL, NULL, 'cipropharm_small.jpg', 'cipropharm.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(45, 3, NULL, NULL, 'cipromid_small.jpg', 'cipromid.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(46, 3, NULL, NULL, 'cefutil_small.jpg', 'cefutil.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(47, 3, NULL, NULL, 'cefix-candle_small.jpg', 'cefix-candle.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(48, 4, NULL, NULL, 'savant_small.jpg', 'savant.jpg', 3, '2009-08-05', '2009-08-05', NULL),
(49, 5, NULL, NULL, 'msd-stand_small.jpg', 'msd-stand.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(50, 5, NULL, NULL, 'hpv_small(1).jpg', 'hpv(1).jpg', 0, '2009-08-05', '0000-00-00', NULL),
(51, 5, NULL, NULL, 'gastrifam_small(1).jpg', 'gastrifam(1).jpg', 0, '2009-08-05', '0000-00-00', NULL),
(52, 5, NULL, NULL, 'dead-sea_small.jpg', 'dead-sea.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(53, 5, NULL, NULL, 'cetamol_small.jpg', 'cetamol.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(54, 5, NULL, NULL, 'activita_small.jpg', 'activita.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(55, 6, NULL, NULL, 'rollup_small.jpg', 'rollup.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(56, 6, NULL, NULL, 'hibor2_small.jpg', 'hibor2.jpg', 0, '2009-08-05', '0000-00-00', NULL),
(57, 6, NULL, NULL, 'hibor1_small.jpg', 'hibor1.jpg', 0, '2009-08-05', '2009-08-05', NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `lab_services`
-- 

CREATE TABLE `lab_services` (
  `service_id` int(11) NOT NULL auto_increment,
  `service_parent_id` int(11) default '0',
  `service_title` varchar(50) character set latin1 collate latin1_general_ci default NULL,
  `service_description` text character set latin1 collate latin1_general_ci,
  `service_order` int(11) default NULL,
  `service_date_submited` date default '0000-00-00',
  `service_date_updated` date default '0000-00-00',
  PRIMARY KEY  (`service_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

-- 
-- Dumping data for table `lab_services`
-- 

INSERT INTO `lab_services` (`service_id`, `service_parent_id`, `service_title`, `service_description`, `service_order`, `service_date_submited`, `service_date_updated`) VALUES 
(1, NULL, 'Graphic Design', '<p>&nbsp;</p>\r\n<table width="100%" cellspacing="1" cellpadding="1" border="0" align="left">\r\n    <tbody>\r\n        <tr>\r\n            <td style="vertical-align: top;">We creatively use visual communication that comprises a skillful combination of text and art work to effectively deliver the client''s message. &nbsp;<br />\r\n            Our graphic design services include: Logos, corporate profiles, vademacum, detail aids, brochures, drop cards, flyers, posters, packs, leaflets, patient leaflets, presentations, stationery, envelops business cards, invitations, magazines, newsletters, books, catalogues, stands, indoor/outdoor signs &amp; promotional items.</td>\r\n            <td>\r\n            <p style="text-align: left; vertical-align: top;"><img width="130" height="80" src="/userfiles/graphic_design(1).gif" alt="" /></p>\r\n            </td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<div style="margin-bottom: 10px; clear: both; background-color: rgb(221, 221, 221); height: 1px;">&nbsp;</div>', 1, '2009-07-27', '2009-08-03'),
(2, NULL, 'Drawings and clipart', '<p>&nbsp;</p>\r\n<table width="100%" cellspacing="1" cellpadding="1" border="0" align="left">\r\n    <tbody>\r\n        <tr>\r\n            <td style="vertical-align: top;">\r\n            <p>We create individualized drawings and clipart for many specialties: medical, pharmaceutical, technical and industrial. And for various applications: websites, presentations and printouts.</p>\r\n            </td>\r\n            <td style="vertical-align: top;"><img width="130" height="80" src="/userfiles/Drawings_and_clipart(1).gif" alt="" /></td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<div style="margin-bottom: 10px; clear: both; background-color: rgb(221, 221, 221); height: 1px;">&nbsp;</div>', 2, '2009-07-27', '2009-08-03'),
(3, NULL, 'Applying specifications of a branding theme', '<p>&nbsp;</p>\r\n<table width="100%" cellspacing="1" cellpadding="1" border="0" align="left">\r\n    <tbody>\r\n        <tr>\r\n            <td style="vertical-align: top;">We are well experienced in applying companies'' printing &amp; design specifications related to the branding theme of a specific product or a line of products. We also offer editing of ready product files to correspond to changing marketing needs while retaining the branding theme.</td>\r\n            <td style="vertical-align: top;"><img width="130" height="80" src="/userfiles/applying_theme(1).gif" alt="" /></td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<div style="margin-bottom: 10px; clear: both; background-color: rgb(221, 221, 221); height: 1px;">&nbsp;</div>', 3, '2009-07-27', '2009-08-03'),
(4, NULL, 'Printing', '<p>&nbsp;</p>\r\n<table width="100%" cellspacing="1" cellpadding="1" border="0" align="left">\r\n    <tbody>\r\n        <tr>\r\n            <td style="">We are committed to providing our customers with consistently high-quality printing services at the lowest possible prices. Our printing services include offset and digital printing.</td>\r\n            <td style=""><img width="130" height="80" alt="" src="/userfiles/printing(1).gif" /></td>\r\n        </tr>\r\n    </tbody>\r\n</table>', 4, '2009-07-27', '2009-08-03'),
(5, NULL, 'Additional Services', '<div style="margin-bottom: 10px; clear: both; background-color: #7D8D99; height: 5px;">&nbsp;</div>', 6, '2009-07-27', '2009-08-04'),
(6, 5, 'Website design', '<p>&nbsp;</p>\r\n<table width="700" cellspacing="1" cellpadding="1" border="0" align="left">\r\n    <tbody>\r\n        <tr>\r\n            <td style="vertical-align: top; width: 570px;">We create eye-catching web sites that are custom tailored specifically to customers'' needs.</td>\r\n            <td style="vertical-align: top;"><img width="130" height="80" src="/userfiles/web_design(1)(1).gif" alt="" /></td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<div style="margin-bottom: 10px; clear: both; background-color: rgb(221, 221, 221); height: 1px;">&nbsp;</div>', 1, '2009-07-27', '2009-08-03'),
(7, 5, 'Copywriting & translation', '<p>&nbsp;</p>\r\n<table width="100%" cellspacing="1" cellpadding="1" border="0" align="left">\r\n    <tbody>\r\n        <tr>\r\n            <td style="vertical-align: top; width: 570px;">Our copywriting services include consultation, research, writing, and review.<br />\r\n            We also offer professional translation of medical, technical and regular documents.</td>\r\n            <td style="vertical-align: top;"><img width="130" height="80" src="/userfiles/copywrite&amp;translation(1).gif" alt="" /></td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<div style="margin-bottom: 10px; clear: both; background-color: rgb(221, 221, 221); height: 1px;">&nbsp;</div>', 2, '2009-07-27', '2009-08-03'),
(8, 5, 'Photography', '<p>&nbsp;</p>\r\n<table width="100%" cellspacing="1" cellpadding="1" border="0" align="left">\r\n    <tbody>\r\n        <tr>\r\n            <td style="vertical-align: top; width: 570px;">We provide professional commercial, documentary &amp; artistic photography services to optimize the outcomes of all types of promotional tools.</td>\r\n            <td style="vertical-align: top;"><img width="130" height="80" src="/userfiles/photography(1).gif" alt="" /></td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<div style="margin-bottom: 10px; clear: both; background-color: rgb(221, 221, 221); height: 1px;">&nbsp;</div>', 3, '2009-07-27', '2009-08-03'),
(9, 5, 'Promotional items', '<p>&nbsp;</p>\r\n<table width="100%" cellspacing="1" cellpadding="1" border="0" align="left">\r\n    <tbody>\r\n        <tr>\r\n            <td style="vertical-align: top; width: 570px;">We offer a wide range of promotional items &amp; gifts specially designed for medical &amp; pharmaceutical marketing purposes and which can be custom tailored for a certain product, a marketing message, or a specific target audience.</td>\r\n            <td style="vertical-align: top;"><img width="130" height="80" src="/userfiles/promotional_items(1).gif" alt="" /></td>\r\n        </tr>\r\n    </tbody>\r\n</table>', 4, '2009-07-27', '2009-08-03');
